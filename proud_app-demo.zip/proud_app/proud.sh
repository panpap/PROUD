java -classpath libs/bcprov-jdk15on-151.jar:libs/commons-codec-1.10.jar:libs/dnsjava-2.1.6.jar:./classes anonDNS
